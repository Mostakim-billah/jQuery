# slider3D

This is 3D slider using JQuery inspired by Microsoft Studio Slider.

## Details
3D slider has a dependency in JQuery. You can check the demo [here](http://renoyes.com/blog_demo/3d_slider). Read the [blog post](http://renoyes.com/create-a-3d-slider-using-background-image/) for more details.
